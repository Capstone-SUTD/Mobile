// ignore: file_names
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class OffsiteChecklistScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Offsite Checklist")),
      body: Center(child: Text("This is the Offsite Checklist Screen")),
    );
  }
}


class OffsiteChecklistScreen extends StatefulWidget {
  @override
  _OffsiteChecklistScreenState createState() => _OffsiteChecklistScreenState();
}

class _OffsiteChecklistScreenState extends State<OffsiteChecklistScreen> {
  List<String> checklistItems = [
    "Review System Generated MS",
    "Fill In Lifting And Lashing Point",
    "Fill In Route Optimization",
    "Upload The Edited MS To System",
    "Confirm All Stakeholders Approved MS",
    "Confirm All Stakeholders Approved MS",
    "Confirm All Stakeholders Approved MS",
  ];

  List<bool> checkedItems = List.generate(7, (index) => false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {},
        ),
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.grey[300],
              child: Icon(Icons.person, color: Colors.black),
            ),
            SizedBox(width: 10),
            Text(
              "Offsite Checklist",
              style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      // Additional screen content can be added here.
    );
  }
}