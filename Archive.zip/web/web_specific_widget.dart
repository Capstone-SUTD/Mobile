import 'package:flutter/material.dart';

class WebSpecificWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('Web Specific Widget'),
    );
  }
}
